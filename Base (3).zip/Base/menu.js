function startgame(){
    window.location = "./game.html"
}